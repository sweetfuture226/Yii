<?php
/**
 * Smith API
 */

require_once('curl/Curl.php');

class SmithApi
{

    private $url = 'https://app.vivasmith.com/api/execute/';

    /**
     * @param $serial
     * @return mixed
     */
    public function getEmployees($serial)
    {
        $data = array(
            'action' => 'getEmployees',
            'serial' => $serial,
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @return mixed
     */
    public function getTeams($serial)
    {
        $data = array(
            'action' => 'getTeams',
            'serial' => $serial,
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @return mixed
     */
    public function getContracts($serial)
    {
        $data = array(
            'action' => 'getContracts',
            'serial' => $serial,
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getTeamMonthlyProductivity($serial, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getTeamMonthlyProductivity',
            'serial' => $serial,
            'filter'   => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $data
     * @return mixed
     */
    public function getEmployeeProductivity($serial, $type ,$filter, $data)
    {
        $data = array(
            'action' => 'getEmployeeProductivity',
            'serial' => $serial,
            'type' => $type,
            'filter' =>$filter,
            'date' => $data
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getProductivityCost($serial, $type,$filter , $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getProductivityCost',
            'serial' => $serial,
            'type' => $type,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getOvertimeProductivity($serial, $type, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getOvertimeProductivity',
            'serial' => $serial,
            'type' => $type,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getAttendanceReport($serial, $type, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getAttendanceReport',
            'serial' => $serial,
            'type' => $type,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $data
     * @return mixed
     */
    public function getProgramsAndSitesProductivity($serial,$type, $filter, $data)
    {
        $data = array(
            'action' => 'getProgramsAndSitesProductivity',
            'serial' => $serial,
            'type' => $type,
            'filter' => $filter,
            'date' => $data
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getIndividualContractProductivity($serial, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getIndividualContractProductivity',
            'serial' => $serial,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getGeneralContractProductivity($serial, $type, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getGeneralContractProductivity',
            'serial' => $serial,
            'type' => $type,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */

    public function getEmployeesContractProductivity($serial, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getEmployeesContractProductivity',
            'serial' => $serial,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */

    public function getContractConsumption($serial, $filter ,$iniDate, $endDate)
    {
        $data = array(
            'action' => 'getContractConsumption',
            'serial' => $serial,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    /**
     * @param $serial
     * @param $type
     * @param $filter
     * @param $iniDate
     * @param $endDate
     * @return mixed
     */
    public function getMetricsReport($serial, $type, $filter, $iniDate, $endDate)
    {
        $data = array(
            'action' => 'getMetricsReport',
            'serial' => $serial,
            'type' => $type,
            'filter' => $filter,
            'iniDate' => $iniDate,
            'endDate' => $endDate
        );

        $output = new Curl();
        return ($output->post($this->url, $data));
    }

    public function init()
    {
        return;
    }
}

?>